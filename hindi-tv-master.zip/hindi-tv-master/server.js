// Hindi TV Master: local server. Serves the player and relays streams so the browser
// is not blocked by CORS, plain-http links, or referrer checks.
// Run:  node server.js     then open http://localhost:8080
const http = require('http');
const fs = require('fs');
const path = require('path');
const { Readable } = require('stream');

const PORT = +process.env.PORT || 8080;
const HOST = process.env.HOST || '127.0.0.1';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
const page = fs.readFileSync(path.join(__dirname, 'index.template.html'), 'utf8')
  .replace('__DATA__', fs.readFileSync(path.join(__dirname, 'data.json'), 'utf8'))
  .replace('/*PROXY*/false', 'true');

const proxyUrl = (u, r) => '/p?u=' + encodeURIComponent(u) + (r ? '&r=' + encodeURIComponent(r) : '');

function rewritePlaylist(text, base, ref) {
  const abs = x => { try { return new URL(x, base).href; } catch { return x; } };
  return text.split(/\r?\n/).map(line => {
    if (!line.trim()) return line;
    if (line.startsWith('#')) return line.replace(/URI="([^"]+)"/g, (_, u) => `URI="${proxyUrl(abs(u), ref)}"`);
    return proxyUrl(abs(line.trim()), ref);
  }).join('\n');
}

async function upstream(target, ref, req, signalMs) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), signalMs);
  const origin = (() => { try { return new URL(target).origin + '/'; } catch { return ''; } })();
  const headers = { 'User-Agent': UA, 'Accept': '*/*', 'Referer': ref || origin };
  if (ref) { try { headers['Origin'] = new URL(ref).origin; } catch {} }
  if (req && req.headers.range) headers['Range'] = req.headers.range;
  const res = await fetch(target, { headers, redirect: 'follow', signal: ctl.signal });
  clearTimeout(t);
  return { res, ctl };
}

const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Expose-Headers': '*' };

async function handleProxy(req, res, q) {
  const target = q.get('u'), ref = q.get('r') || '';
  if (!/^https?:\/\//i.test(target || '')) { res.writeHead(400, cors); return res.end('bad url'); }
  let up;
  try { up = await upstream(target, ref, req, 20000); }
  catch (e) { res.writeHead(502, cors); return res.end('upstream error: ' + (e.cause?.code || e.message)); }
  const r = up.res;
  req.on('close', () => up.ctl.abort());
  if (!r.ok && r.status !== 206) { res.writeHead(r.status, cors); return res.end('upstream ' + r.status); }
  const reader = r.body.getReader();
  const first = await reader.read().catch(() => ({ done: true }));
  const head = first.value ? Buffer.from(first.value) : Buffer.alloc(0);
  const isPlaylist = head.slice(0, 7).toString() === '#EXTM3U';
  if (isPlaylist) {
    let chunks = [head];
    for (;;) { const n = await reader.read().catch(() => ({ done: true })); if (n.done) break; chunks.push(Buffer.from(n.value)); }
    const out = rewritePlaylist(Buffer.concat(chunks).toString('utf8'), r.url || target, ref);
    res.writeHead(200, { ...cors, 'Content-Type': 'application/vnd.apple.mpegurl', 'Cache-Control': 'no-store' });
    return res.end(out);
  }
  const h = { ...cors, 'Content-Type': r.headers.get('content-type') || 'application/octet-stream' };
  for (const k of ['content-length', 'content-range', 'accept-ranges']) if (r.headers.get(k)) h[k] = r.headers.get(k);
  res.writeHead(r.status, h);
  if (head.length) res.write(head);
  (async () => {
    try { for (;;) { const n = await reader.read(); if (n.done) break; if (!res.write(Buffer.from(n.value))) await new Promise(ok => res.once('drain', ok)); } }
    catch {} finally { res.end(); }
  })();
}

async function handleCheck(req, res, q) {
  const target = q.get('u'), ref = q.get('r') || '';
  const send = o => { res.writeHead(200, { ...cors, 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
  if (!/^https?:\/\//i.test(target || '')) return send({ ok: false, why: 'bad url' });
  try {
    const { res: r, ctl } = await upstream(target, ref, null, 8000);
    if (!r.ok) { ctl.abort(); return send({ ok: false, why: 'HTTP ' + r.status }); }
    const buf = Buffer.from(await r.arrayBuffer().catch(() => new ArrayBuffer(0))).slice(0, 4000);
    ctl.abort();
    const txt = buf.toString('utf8');
    if (!txt.startsWith('#EXTM3U')) return send({ ok: false, why: 'not a playlist' });
    return send({ ok: true });
  } catch (e) { return send({ ok: false, why: e.name === 'AbortError' ? 'timeout' : (e.cause?.code || e.message) }); }
}

http.createServer((req, res) => {
  const host = (req.headers.host || '').split(':')[0];
  if (HOST === '127.0.0.1' && !['localhost', '127.0.0.1'].includes(host)) { res.writeHead(403); return res.end(); }
  const u = new URL(req.url, 'http://x');
  if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }
  if (u.pathname === '/p') return handleProxy(req, res, u.searchParams);
  if (u.pathname === '/check') return handleCheck(req, res, u.searchParams);
  if (u.pathname === '/' || u.pathname === '/index.html') { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(page); }
  res.writeHead(404); res.end('not found');
}).listen(PORT, HOST, () => console.log(`Hindi TV Master running at http://localhost:${PORT}  (Ctrl+C to stop)`));
