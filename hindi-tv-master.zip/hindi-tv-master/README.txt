Hindi TV Master
1. Install Node.js 18 or newer (https://nodejs.org).
2. In this folder run:   node server.js
3. Open http://localhost:8080 in Chrome, Edge or Firefox.
4. Click "Scan all channels" once. Live channels get a LIVE tag; tick "Hide offline" to show only working ones.

The server relays each stream so the browser is not blocked by CORS, http-only links or referrer checks.
It only listens on your own computer. Run it from India (or an Indian VPN) because many channels are geo-locked.
